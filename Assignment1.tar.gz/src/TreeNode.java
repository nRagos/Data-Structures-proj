package src;

public class TreeNode {
        String data;
        TreeNode left, right;

    /**
     * nodes in BST
     * @param data of string value stored in node
     */
    public TreeNode(String data){
            this.data=data;
            this.left=null;
            this.right=null;
        }

}
